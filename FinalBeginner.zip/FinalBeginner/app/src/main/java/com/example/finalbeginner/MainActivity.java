package com.example.finalbeginner;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
    private EditText lineBeratBadan;
    private EditText lineTinggiBadan;
    private EditText lineHasil;
    private Button btnHitung;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        lineBeratBadan = (EditText) findViewById(R.id.lineBeratBadan);
        lineTinggiBadan =(EditText) findViewById(R.id.lineTinggiBadan);
        lineHasil=(EditText) findViewById(R.id.txtHasil);
        btnHitung=(Button)findViewById(R.id.btnHitung);

        getSupportActionBar().setTitle("Hitung Rumusan BMI");

        btnHitung.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String BB , TB;
                BB =  lineBeratBadan.getText().toString();
                TB = lineTinggiBadan.getText().toString();

                // Required Rumus BMI
                if (TextUtils.isEmpty(BB)) {
                    lineBeratBadan.setError("Tidak Boleh Kosong!!!");
                    lineBeratBadan.requestFocus();
                } else if (TextUtils.isEmpty(TB)) {
                    lineTinggiBadan.setError("Tidak Boleh Kosong!!!");
                    lineTinggiBadan.requestFocus();
                } else {

                    // Masukan Rumus untuk menghitung
                    double beratBadan = Double.parseDouble(lineBeratBadan.getText().toString());
                    double tinggiBadan = Double.parseDouble(lineTinggiBadan.getText().toString());
                    double hasil = (beratBadan / tinggiBadan * tinggiBadan);

                    // View Hasil
                    lineHasil.setText("Hasil Rumusan BMI adalah "  + hasil);
                }

            }
        });
    }
}




